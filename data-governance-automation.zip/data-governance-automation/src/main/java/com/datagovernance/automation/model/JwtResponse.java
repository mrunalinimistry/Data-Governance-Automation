package com.datagovernance.automation.model;

import java.io.Serializable;

public class JwtResponse implements Serializable {
	private  String Authorization;

	
	public JwtResponse(String authorization) {
		super();
		Authorization = authorization;
	}

	public String getAuthorization() {
		return Authorization;
	}

}
