package com.datagovernance.automation.model;

import java.io.Serializable;

/*
 * This class will accept client name and secret from Post Request.
 * 
 */

public class JwtRequest implements Serializable {
	private String clientName;
	private String secret;

	public JwtRequest() {
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getSecret() {
		return secret;
	}

	public void setSecret(String secret) {
		this.secret = secret;
	}

}