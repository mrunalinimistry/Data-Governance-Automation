package com.datagovernance.automation.service.declaration;


import com.datagovernance.automation.model.JwtRequest;

public interface JwtAuthenticationService {
	
	public String generateJWTToken(JwtRequest authenticationRequest);

	public String getJWTAuthenticationToken(JwtRequest authenticationRequest); 
}
