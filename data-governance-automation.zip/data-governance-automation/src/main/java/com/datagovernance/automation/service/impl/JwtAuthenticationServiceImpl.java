package com.datagovernance.automation.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.datagovernance.automation.config.CacheConfiguration;
import com.datagovernance.automation.constants.ApplicationConstants;
import com.datagovernance.automation.model.JwtRequest;
import com.datagovernance.automation.service.declaration.JwtAuthenticationService;
import com.datagovernance.automation.utils.JwtTokenUtil;

@Service
public class JwtAuthenticationServiceImpl implements JwtAuthenticationService {
	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	@Autowired
	private CacheConfiguration cacheConfiguration;

	@Override
	public String generateJWTToken(JwtRequest authenticationRequest) {

		final String jwtToken = jwtTokenUtil.generateToken(authenticationRequest);
		final String token = ApplicationConstants.TOKEN_PREFIX + " " + jwtToken;

		return token;
	}

	@Override
	public String getJWTAuthenticationToken(JwtRequest authenticationRequest) {

		String token = "";
		if (authenticationRequest.getClientName() != null) {
			token = cacheConfiguration.GetTokenFromRedisCache(authenticationRequest);
		}
		return token;
	}

}
