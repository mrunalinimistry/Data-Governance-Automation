package com.datagovernance.automation.config;

import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import com.datagovernance.automation.constants.ApplicationConstants;
import com.datagovernance.automation.model.JwtRequest;
import com.datagovernance.automation.service.declaration.JwtAuthenticationService;
import com.datagovernance.automation.utils.RedisUtil;

@Component
public class CacheConfiguration {

	@Autowired
	RedisUtil redisUtil;

	@Autowired
	JwtAuthenticationService jwtAuthenticationService;

	public String GetTokenFromRedisCache(JwtRequest authenticationRequest) {

		String token = null;
		if (redisUtil.getMapAsAll(ApplicationConstants.JWT_TOKEN) != null && redisUtil
				.getMapAsSingleEntry(ApplicationConstants.JWT_TOKEN, authenticationRequest.getClientName()) != null) {
			token = (String) redisUtil.getMapAsSingleEntry(ApplicationConstants.JWT_TOKEN,
					authenticationRequest.getClientName());
		} else {

			token = jwtAuthenticationService.generateJWTToken(authenticationRequest);
			redisUtil.putMap(ApplicationConstants.JWT_TOKEN, authenticationRequest.getClientName(), token);
			redisUtil.setExpire(ApplicationConstants.JWT_TOKEN, 1, TimeUnit.HOURS);
		}
		return token;
	}

}
