package com.datagovernance.automation.constants;

import java.io.Serializable;

public class ApplicationConstants implements Serializable{

	public static final String JWT_TOKEN = "JWT_TOKEN";
	
	public static final String TOKEN_PREFIX = "Bearer";

	
	
	
}
