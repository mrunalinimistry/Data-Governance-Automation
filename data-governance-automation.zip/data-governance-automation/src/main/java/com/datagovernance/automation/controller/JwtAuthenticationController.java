package com.datagovernance.automation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.datagovernance.automation.model.JwtRequest;
import com.datagovernance.automation.model.JwtResponse;
import com.datagovernance.automation.service.declaration.JwtAuthenticationService;

@RestController
@CrossOrigin
public class JwtAuthenticationController {

	@Autowired
	private JwtAuthenticationService jwtAuthenticationService;

	@Value("${jwt.secret}")
	private String secret;

	@Value("${jwt.clientname}")
	private String clientName;

	@RequestMapping(value = "/authenticate", method = RequestMethod.POST)
	public ResponseEntity<?> createAuthenticationToken(@RequestBody JwtRequest authenticationRequest) throws Exception {
		String token = null;
		if (clientName.equals(authenticationRequest.getClientName())
				&& secret.equals(authenticationRequest.getSecret())) {
			
			token = jwtAuthenticationService.getJWTAuthenticationToken(authenticationRequest);
			return ResponseEntity.ok(new JwtResponse(token));

		}
		else {
			return ResponseEntity.badRequest().body("Invalid client name / secret");

		}

	}

}
