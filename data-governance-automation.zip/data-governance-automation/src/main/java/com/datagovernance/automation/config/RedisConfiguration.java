package com.datagovernance.automation.config;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.springframework.boot.autoconfigure.data.redis.RedisProperties;
import org.springframework.boot.autoconfigure.data.redis.RedisProperties.Sentinel;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisNode;
import org.springframework.data.redis.connection.RedisSentinelConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.GenericToStringSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.util.StringUtils;

import com.datagovernance.automation.constants.ApplicationConstants;

@Configuration
public class RedisConfiguration {
	/**
	 * This method is used to connect Redis server for master, slave and sentinel
	 * nodes.
	 * 
	 * @return {@link LettuceConnectionFactory}
	 */
	@Bean
	public LettuceConnectionFactory lettuceConnectionFactory(RedisProperties redisProperties) {

		Sentinel sentinelProperties = redisProperties.getSentinel();

		RedisSentinelConfiguration sentinelConfiguration = new RedisSentinelConfiguration();
		sentinelConfiguration.master(sentinelProperties.getMaster());
		sentinelConfiguration.setSentinels(createSentinels(sentinelProperties));
		// sentinelConfiguration.setPassword(RedisPassword.of(redisProperties.getPassword()));

		return new LettuceConnectionFactory(sentinelConfiguration);

	}

	/**
	 * This method is used to create Redis Template.
	 * 
	 * @return {@link RedisTemplate}
	 */
	@Bean
	public RedisTemplate<String, Object> redisTemplate(RedisProperties redisProperties) {
		final RedisTemplate<String, Object> template = new RedisTemplate<>();
		template.setConnectionFactory(lettuceConnectionFactory(redisProperties));
		template.setDefaultSerializer(new GenericJackson2JsonRedisSerializer());
		template.setKeySerializer(new StringRedisSerializer());
		template.setHashKeySerializer(new GenericJackson2JsonRedisSerializer());
		template.setValueSerializer(new GenericJackson2JsonRedisSerializer());

		return template;
	}

	public List<RedisNode> createSentinels(Sentinel sentinel) {
		List<RedisNode> nodes = new ArrayList<>();
		for (String node : sentinel.getNodes()) {
			try {
				String[] parts = StringUtils.split(node, ":");
				nodes.add(new RedisNode(parts[0], Integer.valueOf(parts[1])));
			} catch (RuntimeException ex) {
				throw new IllegalStateException("Invalid redis sentinel property '" + node + "'", ex);
			}
		}
		return nodes;
	}
}