package com.datagovernance.automation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataGovernanceAutomationApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataGovernanceAutomationApplication.class, args);
	}

}
